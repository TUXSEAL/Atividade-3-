from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('detalhe/<str:id_post>/', views.detalhe, name='detalhe'),
    path('delete_comment/<int:id_post>/<int:comment_index>/', views.delete_comment, name='delete_comment'),
]