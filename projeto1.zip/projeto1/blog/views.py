import requests
import json
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.cache import never_cache

# Função auxiliar para tratamento de erros da API
def safe_api_call(method, url, data=None):
    try:
        if method == "POST":
            response = requests.post(url, json=data)
        elif method == "PUT":
            response = requests.put(url, json=data)
        response.raise_for_status()  
        return response.json()
    except requests.RequestException as e:
        return {"error": str(e), "data": data}

def index(request):
    # Contextos dos posts
    posts = [
        {
            "name": "6G atinge taxa de transmissão 5.000 vezes maior que 5G",
            "data": {
                "texto": "A University College de Londres (UCL) conseguiu atingir uma taxa de transmissão de dados de 938 Gb/s com a rede 6G.",
                "pub_date": "11/11/2024",
                "img": "https://network-king.net/wp-content/uploads/2024/07/6G-769x450.jpg",
                "comentarios": [
                    {"comment": "Para o consumidor final no BR: velocidade vai ser próxima a do 4G."},
                    {"comment": "Top!"}
                ],
            },
        },
        {
            "name": "Snapdragon 8 Elite é o novo chip da Qualcomm para celulares avançados",
            "data": {
                "texto": "Snapdragon 8 Elite é o nome do novo chip da Qualcomm para celulares de alto desempenho.",
                "pub_date": "12/11/2024",
                "img": "https://files.tecnoblog.net/wp-content/uploads/2024/10/snapdragon-8-elite-celular-768x432.jpg",
                "comentarios": [
                    {"comment": "Para o consumidor final no BR: velocidade vai ser próxima a do 4G."},
                    {"comment": "Top!"}
                ],
            },
        },
    ]
    
    # Enviar os posts para a API
    post_data = [safe_api_call("POST", "https://api.restful-api.dev/objects", data=post) for post in posts]

    return render(request, 'index.html', {'posts_template': post_data})

@never_cache
def detalhe(request, id_post):
    # Primeiro contexto (context1)
    context1 = {
        "name": "6G atinge taxa de transmissão 5.000 vezes maior que 5G",
        "data": {
            "texto": "A University College de Londres (UCL) conseguiu atingir uma taxa de transmissão de dados de 938 Gb/s com a rede 6G.",
            "pub_date": "11/11/2024",
            "img": "https://media.datacenterdynamics.com/media/images/GettyImages-1716219674.width-880.jpg",
            "comentarios": [
                {"comment": "Para o consumidor final no BR: velocidade vai ser próxima a do 4G."},
                {"comment": "Top!"},
                {"comment": "UIiiiiiiiiiii!"},
            ],
        },
    }

    # Enviar o primeiro contexto para a API
    post_data = safe_api_call("POST", "https://api.restful-api.dev/objects", data=context1)

    # Verificar se o segundo contexto deve ser ativado
    # passe na url /?activate_context2=true or false
    activate_context2 = request.GET.get('activate_context2', 'false').lower() == 'true'
    comments = [post_data]  # Inicializa os dados com context1

    if activate_context2:
        # Segundo contexto (context2)
        context2 = {
            "name": "6G atinge taxa de transmissão 5.000 vezes maior que 5G",
            "data": {
                "texto": "A University College de Londres (UCL) conseguiu atingir uma taxa de transmissão de dados de 938 Gb/s com a rede 6G.",
                "pub_date": "11/11/2024",
                "img": "https://media.datacenterdynamics.com/media/images/GettyImages-1716219674.width-880.jpg",
                "comentarios": [
                    {"comment": "Comentário Atualizado: velocidade vai ser próxima a do 4G."},
                    {"comment": "Comentário Atualizado: Top!"},
                    {"comment": "Muto bom!"},
                    {"comment": "Graças a Deus!"},
                    {"comment": "10/10"},
                ],
            },
        }

        # Atualizar o contexto na API
        updated_data = safe_api_call("PUT", f"https://api.restful-api.dev/objects/{id_post}", data=context2)
        comments = [updated_data]

    # Salvar dados no arquivo
    with open("responses.txt", "w") as file:
        file.write(json.dumps(comments, indent=4))

    return render(request, 'detalhe.html', {'post_template': comments})

from django.http import JsonResponse, HttpResponseBadRequest

def delete_comment(request, id_post, comment_index):
    """
    Exclui um comentário específico com base no índice no objeto de dados.
    """
    try:
        # Buscar o post correspondente na API
        post_data = safe_api_call("GET", f"https://api.restful-api.dev/objects/{id_post}")
        
        if "error" in post_data:
            return JsonResponse({"error": "Post não encontrado na API."}, status=404)

        # Remover o comentário pelo índice
        try:
            post_data['data']['comentarios'].pop(comment_index)
        except IndexError:
            return JsonResponse({"error": "Índice do comentário inválido."}, status=400)

        # Atualizar o post na API sem o comentário excluído
        updated_post = safe_api_call("PUT", f"https://api.restful-api.dev/objects/{id_post}", data=post_data)

        if "error" in updated_post:
            return JsonResponse({"error": "Erro ao atualizar o post na API."}, status=500)

        return JsonResponse({"success": "Comentário excluído com sucesso.", "updated_post": updated_post})
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)

